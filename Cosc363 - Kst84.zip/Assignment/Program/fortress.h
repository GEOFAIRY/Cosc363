#pragma once
#ifndef FORTRESS_H   // To make sure you don't declare the function more than once by including the header multiple times.
#define FORTRESS_H

#include <math.h>
#include <GL/freeglut.h>
#include <iostream>

void walls();

#endif#pragma once
