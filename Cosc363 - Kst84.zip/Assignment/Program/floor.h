#pragma once
#ifndef FLOOR_H   // To make sure you don't declare the function more than once by including the header multiple times.
#define FLOOR_H

#include <math.h>
#include <GL/freeglut.h>
#include <iostream>

void floor(GLuint txId[8]);

#endif