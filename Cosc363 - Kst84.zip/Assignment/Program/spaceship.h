#pragma once
#ifndef SPACESHIP_H   // To make sure you don't declare the function more than once by including the header multiple times.
#define SPACESHIP_H

#include <GL/freeglut.h>

void spaceship();
void spinTimer(int value);

#endif#pragma once
