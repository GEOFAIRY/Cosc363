#pragma once
#ifndef ROBOT2_H   // To make sure you don't declare the function more than once by including the header multiple times.
#define ROBOT2_H

#include <GL/freeglut.h>

void robot2();
void walkTimer2(int value);

#endif